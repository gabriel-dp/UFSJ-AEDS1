#include <stdio.h>

void main () {
    float num1, num2;
    printf("\nDigite 2 numeros float:\n");
    scanf("%f %f", &num1, &num2);
    printf("\n%f | %f\n\n", num1, num2);
}